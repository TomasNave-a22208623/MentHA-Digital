from django.apps import AppConfig


class ProtocoloConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'protocolo'
