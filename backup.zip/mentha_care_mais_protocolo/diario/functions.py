def multiple_appends(listname, *element):
    listname.extend(element)